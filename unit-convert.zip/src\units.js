// 单位换算插件的数据文件。
//
// 换算模型是线性的：base = v * factor + offset
//   - 长度：base = 米
//   - 重量：base = 千克
//   - 温度：base = 摄氏度（华氏 / 开尔文靠 offset 表达）
//
// 这个文件是故意放在子目录 src/ 里的：用来验证「插件包里的相对路径资源能不能加载」。
var WWL_UNITS = [
  {
    id: 'length',
    name: '长度',
    items: [
      { id: 'm', name: '米', factor: 1, offset: 0 },
      { id: 'km', name: '千米', factor: 1000, offset: 0 },
      { id: 'cm', name: '厘米', factor: 0.01, offset: 0 },
      { id: 'mm', name: '毫米', factor: 0.001, offset: 0 },
      { id: 'inch', name: '英寸', factor: 0.0254, offset: 0 },
      { id: 'foot', name: '英尺', factor: 0.3048, offset: 0 },
      { id: 'yard', name: '码', factor: 0.9144, offset: 0 },
      { id: 'mile', name: '英里', factor: 1609.344, offset: 0 }
    ]
  },
  {
    id: 'weight',
    name: '重量',
    items: [
      { id: 'kg', name: '千克', factor: 1, offset: 0 },
      { id: 'g', name: '克', factor: 0.001, offset: 0 },
      { id: 'mg', name: '毫克', factor: 0.000001, offset: 0 },
      { id: 't', name: '吨', factor: 1000, offset: 0 },
      { id: 'jin', name: '斤', factor: 0.5, offset: 0 },
      { id: 'liang', name: '两', factor: 0.05, offset: 0 },
      { id: 'lb', name: '磅', factor: 0.45359237, offset: 0 },
      { id: 'oz', name: '盎司', factor: 0.028349523125, offset: 0 }
    ]
  },
  {
    id: 'temp',
    name: '温度',
    items: [
      { id: 'c', name: '摄氏度', factor: 1, offset: 0 },
      { id: 'f', name: '华氏度', factor: 5 / 9, offset: -160 / 9 },
      { id: 'k', name: '开尔文', factor: 1, offset: -273.15 }
    ]
  }
];
